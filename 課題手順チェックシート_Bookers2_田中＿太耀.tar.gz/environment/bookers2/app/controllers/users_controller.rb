class UsersController < ApplicationController
  def index
     @books = Book.all
      @books = Book.includes(:user).all
      @users = User.all
      @user = current_user
       @books = @user.books
  end

  def show
    @user = User.find(params[:id])
      @user = User.find_by(id: params[:id])
       @books = @user.books
  end

  def edit
    @user = User.find(params[:id])
     @book = Book.find(params[:id])  
    
    if @user == current_user
        render "edit"
    else
      redirect_to user_path(current_user)
    end
  end
   def update

    # ---- ここからコードを書きましょう ---- #
    @user = User.find(params[:id])
    if @user.update(user_params)
    redirect_to user_path(@user)
    flash[:notice] = "Book was successfully updated."
    # ---- ここまでのあいだにコードを書きましょう ---- #
    else
     render :edit
    end
   end

  private

  def user_params
    params.require(:user).permit(:name, :introduction,:profile_image)
  end
end
