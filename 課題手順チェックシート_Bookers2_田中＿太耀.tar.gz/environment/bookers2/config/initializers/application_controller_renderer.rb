# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '9e3a8e9823162604ff54223cc6f8ec32b67452a104af88dcb2831bd816eed855b131b780fc062ae9b03b4d8000c1ce12a49854e6cbd4ddf7e5cafcd827e123c1'